package AST;

import Errors.*;

public interface LDecl {
    // Esta es la interfaz del no terminal <LDecl>
};