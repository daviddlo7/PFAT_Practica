package AST;

import Errors.*;

public class StatementList_ReglaProd1 implements StatementList {

    public Statement statement;

    public StatementList_ReglaProd1(Statement statement) {

        this.statement = statement;
    }

}
