package AST;

import Errors.*;

public interface IdentList {
    // Esta es la interfaz del no terminal <IdentList>
};
