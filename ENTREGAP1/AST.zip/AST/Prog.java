package AST;

import Errors.*;

public interface Prog {
    // Esta es la interfaz del no terminal <Prog>
};
