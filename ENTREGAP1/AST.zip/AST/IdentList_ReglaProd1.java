package AST;

import Errors.*;

public class IdentList_ReglaProd1 implements IdentList {
    public String ident;

    public IdentList_ReglaProd1(String ident) {
        this.ident = ident;
    }
}
