package AST;

import Errors.*;

public interface Statement {

};
