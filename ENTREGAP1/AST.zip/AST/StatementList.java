package AST;

import Errors.*;

public interface StatementList {
    // Esta es la interfaz del no terminal <StatementList>
};