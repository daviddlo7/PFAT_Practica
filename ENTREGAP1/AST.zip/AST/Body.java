package AST;

import Errors.*;

public interface Body {
    // Esta es la interfaz del no terminal <Body>
};
