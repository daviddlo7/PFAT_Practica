package AST;

import Errors.*;

public class Exp_NDecimal implements Exp {

    public int ctedecimal;

    public Exp_NDecimal(int ctedecimal) {
        this.ctedecimal = ctedecimal;
    }
}
