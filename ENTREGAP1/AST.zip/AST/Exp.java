package AST;

import Errors.*;

public interface Exp {
    // Esta es la interfaz del no terminal <Java>
};
